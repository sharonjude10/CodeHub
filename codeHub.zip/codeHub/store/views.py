from django.forms import BaseModelForm
from django.http import HttpResponse
from django.shortcuts import render,redirect

from django.views.generic import View,TemplateView,UpdateView,CreateView,DetailView,ListView,FormView
from store.forms import SignUpForm,SignInForm,UserProfileForm,ProjectForm,ReviewForm
from django.contrib.auth import authenticate,login
from store.models import UserProfile,Project,WishListItems,OrderSummary,Reviews
from django.urls import reverse,reverse_lazy
from django.db.models import Sum






class SignUpView(View):
    def get(self,request,*args,**kwargs):
        form_instance=SignUpForm()
        return render(request,"store/signup.html",{"form":form_instance})
    def post(self,request,*args,**kwargs):
        form_instance=SignUpForm(request.POST)
        if form_instance.is_valid():
            form_instance.save()
            return redirect("signin")
        return render(request,"store/signup.html",{"form":form_instance})
    
class SignInView(View):
    def get(self,request,*args,**kwargs):
        form_instance=SignInForm()
        return render(request,"store/login.html",{"form":form_instance})
    def post(self,request,*args,**kwargs):
        form_instance=SignInForm(request.POST)
        if form_instance.is_valid():
            data=form_instance.cleaned_data
            user_obj=authenticate(request,**data)
            if user_obj:
                login(request,user_obj)
                return redirect("index")
            
        return render(request,"store/login.html",{"form":form_instance})
    


KEY_SECRET="kEduhDbW8vFcnp2zF2W5o5qQ"

KEY_ID="rzp_test_Ee7cmjigjbQSkl"


class IndexView(View):
    template_name="store/index.html"
    def get(self,request,*args,**kwargs):
        qs=Project.objects.all().exclude(owner=request.user)
        return render(request,self.template_name,{"projects":qs})
#method 1
# class UserProfileUpdateView(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("pk")
#         profile_obj=UserProfile.objects.get(id=id)
#         form_instance=UserProfileForm(instance=profile_obj)
#         return render(request,"store/profile_edit.html",{"form":form_instance})

#method 2
class UserProfileUpdateView(UpdateView):
    model=UserProfile
    form_class=UserProfileForm
    template_name="store/profile_edit.html"
    # def get_success_url(self):
    #     return reverse("index")
    success_url=reverse_lazy("index")

class ProjectCreateView(CreateView):
    model=Project
    form_class=ProjectForm
    template_name="store/project_add.html"
    success_url=reverse_lazy("index")

    #method 1
    #method overriding
    def form_valid(self, form):
        form.instance.owner=self.request.user
        return super().form_valid(form)
    
    #method 2
    # def post(self,request,*args,**kwargs):
    #     form_instance=ProjectForm(request.POST,files=request.FILES)
    #     if form_instance.is_valid():
    #         form_instance.instance.owner=request.user
    #         form_instance.save()
    #         return redirect("index")
    #     else:
    #         return redirect(request,self.template_name,{"form":form_instance})

class MyProjectListView(View):
    def get(self,request,*args,**kwargs):
        #qs=request.user.projects.all()
        qs=Project.objects.filter(owner=request.user)
        return render(request,"store/myprojects.html",{"works":qs})
    
class ProjectDeleteView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        Project.objects.get(id=id).delete()
        return redirect("myworks")
    
class ProjectDetailView(DetailView):
        template_name="store/project_detail.html"
        context_object_name="project"
        model=Project

        #method 2
        # def get(self,request,*args,**kwargs):

        #     id=kwargs.get("pk")
        #     qs=project.objects.get(id=id)
        #     return render(request,"store/project_detail.html",{"project":qs})
        
    
class AddToWishlistView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        project_obj=Project.objects.get(id=id)
        WishListItems.objects.create(
                                        wishlist_object=request.user.basket,
                                        project_object=project_obj
                                     )
        print('item added')
        return redirect("index")
    
class MyCartView(View):
    def get(self,request,*args,**kwargs):
        qs=request.user.basket.basket_items.filter(is_order_placed=False)
        total=request.user.basket.wishlist_total
        return render(request,"store/wishlist_summary.html",{"cartitems":qs,"total":total})
    
class WishListItemDeleteView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        WishListItems.objects.get(id=id).delete()
        return redirect("my-cart")

import razorpay

class CheckOutView(View):
    def get(self,request,*args,**kwargs):
        client = razorpay.Client(auth=(KEY_ID, KEY_SECRET))
        amount=request.user.basket.wishlist_total*100
        data = { "amount": amount, "currency": "INR", "receipt": "order_rcptid_11" }
        payment = client.order.create(data=data)

        #create order_object
        cart_items=request.user.basket.basket_items.filter(is_order_placed=False)
        order_summary_obj=OrderSummary.objects.create(
            user_object=request.user,
            order_id=payment.get("id"),
            total=request.user.basket.wishlist_total
        )

        
        # order_summary_obj.project_objects.add(cart_items.values("project_object"))

        for ci in cart_items:
            order_summary_obj.project_objects.add(ci.project_object)
            order_summary_obj.save()
        
        # for ci in cart_items:
        #     ci.is_order_placed=True
        #     ci.save()
        
        
        context={
            "key":KEY_ID,
            "amount":data.get('amount'),
            "currency":data.get('currency'),
            "order_id":payment.get('id')
        }
        return render(request,'store/payment.html',context)


from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

"""{
'razorpay_payment_id': ['pay_P9zfvPGXMeiNaJ'],
'razorpay_order_id': ['order_P9zetDVrJ6tVvt'], 
'razorpay_signature': ['80d7f0a166974a51ae3f8a9482dcb82217eac82403208efa3be6a86d787b7bb0']
}"""

@method_decorator(csrf_exempt,name='dispatch')
class PaymentVerificationView(View):
    def post(self,request,*args,**kwargs):
        print(request.POST)
        client = razorpay.Client(auth=(KEY_ID, KEY_SECRET))
        #to retain current user....otherwise error will raise
        order_summary_object=OrderSummary.objects.get(order_id=request.POST.get("razorpay_order_id"))
        login(request,order_summary_object.user_object)
        try:
             #doubtful code
            client.utility.verify_payment_signature(request.POST)
            print("payment success")
            order_id=request.POST.get("razorpay_order_id")
            OrderSummary.objects.filter(order_id=order_id).update(is_paid=True)
            cart_items=request.user.basket.basket_items.filter(is_order_placed=False)
            
            for ci in cart_items:
                ci.is_order_placed=True
                ci.save()

        except:
            #handling code
            print("payment failed")

        #return render(request,'store/success.html')
        return redirect("index")    
    
class MyPurchaseView(ListView):
    model:OrderSummary
    context_object_name="orders"

    def get(self,request,*args,**kwargs):
        qs=OrderSummary.objects.filter(user_object=request.user,is_paid=True).order_by('-created_date')
        return render(request,"store/order_summary.html",{"orders":qs})
    
#url: lh:8000/<int:pk>/review/add/
class ReviewCreateView(FormView):
        template_name="store/review.html"
        form_class=ReviewForm


        def post(self,request,*args,**kwargs):
            id=kwargs.get("pk")
            project_obj=Project.objects.get(id=id)
            form_instance=ReviewForm(request.POST)
            if form_instance.is_valid():
                form_instance.instance.user_object=request.user
                form_instance.instance.project_object=project_obj
                form_instance.save()
                return redirect("index")
            else:
                return render(request,self.template_name,{"form":form_instance})